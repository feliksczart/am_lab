package com.example.cocktailmenu

import android.content.Context
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.*
import androidx.fragment.app.Fragment
import androidx.fragment.app.FragmentContainerView
import androidx.fragment.app.ListFragment
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.RecyclerView
import kotlin.properties.Delegates


class CocktailListFragment : Fragment() {

    private var myAdapter: RecyclerView.Adapter<*>? = null
    var isEditing: Boolean = false
    var IS_EDITING_KEY by Delegates.notNull<Boolean>()

    interface Listener {
        fun itemClicked(id: Long)
    }

    private var listener: Listener? = null

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {

        //TODO GRID
        val fragview: View = inflater.inflate(R.layout.fragment_cocktail_list, container, false)
        val rootViewx: View? = super.onCreateView(inflater, container, savedInstanceState)

        val names = arrayOfNulls<String>(Cocktail.cocktails.size)
        for (i in names.indices) {
            names[i] = Cocktail.cocktails[i].getName()
        }
//        val adapter: Any = ArrayAdapter<Any?>(
//            inflater.context, android.R.layout.simple_list_item_1, names
//        )
//        listAdapter = adapter as ListAdapter?

        val myrv = fragview.findViewById<RecyclerView>(R.id.recycleview)
        val gridManager = GridLayoutManager(context, 2, GridLayoutManager.VERTICAL, false)
        myAdapter = CustomAdapter(context, names, null)
        myrv.adapter = myAdapter
        myrv.layoutManager = gridManager
        myrv.hasFixedSize()

        return rootViewx
    }

    override fun onAttach(context: Context) {
        super.onAttach(context)
        listener = context as Listener
    }

//    override fun onListItemClick(l: ListView, v: View, position: Int, id: Long) {
//        listener?.itemClicked(id)
//    }
}