package com.example.cocktailmenu

import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView

class CustomAdapter(private val context: Context?, private val titles: Array<String?>, private val images: List<Int>?) : RecyclerView.Adapter<CustomAdapter.ViewHolder>() {

    class ViewHolder(view: View) : RecyclerView.ViewHolder(view) {
        //var imageview: ImageView
        var textview: TextView

        init {
            //imageview = view.findViewById(R.id.imageview)
            textview = view.findViewById(R.id.textview)
        }
    }

    override fun onCreateViewHolder(viewGroup: ViewGroup, viewType: Int): ViewHolder {
        val view = LayoutInflater.from(viewGroup.context)
            .inflate(R.layout.grid_item, viewGroup, false)

        return ViewHolder(view)
    }

    override fun onBindViewHolder(viewHolder: ViewHolder, position: Int) {
        viewHolder.textview.text = titles[position]
        //viewHolder.imageview.setImageResource(images[position])
    }

    override fun getItemCount() = titles.size
}